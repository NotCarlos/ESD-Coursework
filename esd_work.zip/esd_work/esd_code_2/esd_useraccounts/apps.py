from django.apps import AppConfig


class EsdUseraccountsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'esd_useraccounts'
