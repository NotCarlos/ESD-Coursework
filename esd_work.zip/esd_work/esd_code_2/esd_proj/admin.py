from django.contrib import admin
from esd_proj.models import ClubMember, Club, PaymentMethod
# Register your models here.

admin.site.register(Club)
admin.site.register(ClubMember)
admin.site.register(PaymentMethod)